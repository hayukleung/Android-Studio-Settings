#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

public class ${NAME}Adapter extends RecyclerView.Adapter<${NAME}Adapter.DataViewHolder> {

    private final List<${NAME}Data> mList = new ArrayList<>(0);

    public void setList(List<${NAME}Data> list) {
        mList.clear();
        mList.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        ${NAME}Data data = mList.get(position);
        holder.bindData(data);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {

        public DataViewHolder(View itemView) {
            super(itemView);
        }

        void bindData(final ${NAME}Data data) {
        }
    }
}
