#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}Contract {

    public interface Presenter extends BasePresenter {
    
        void query();
    }

    public interface View extends BaseView<Presenter> {
    
        void ui(List<${NAME}Data> data);
    }
}