#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}DataMocker implements Mockable<List<${NAME}Data>> {

    @Override
    public List<${NAME}Data> mock() {

        List<${NAME}Data> list = new ArrayList<>(10);
        ${NAME}Data data;

        data = new ${NAME}Data();
        data.name = "1";
        list.add(data);

        data = new ${NAME}Data();
        data.name = "2";
        list.add(data);

        data = new ${NAME}Data();
        data.name = "3";
        list.add(data);
        
        data = new ${NAME}Data();
        data.name = "4";
        list.add(data);
        
        return list;
    }
}