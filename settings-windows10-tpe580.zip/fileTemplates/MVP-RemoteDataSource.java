#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}RemoteDataSource implements ${NAME}DataSource {

    private ${NAME}Service mService;

    private ${NAME}RemoteDataSource() {
        mService = NetService.create(${NAME}Service.class);
    }

    public static ${NAME}RemoteDataSource newInstance() {
        return new ${NAME}RemoteDataSource();
    }
    
    interface ${NAME}Service {
        @GET("TODO")
        Observable<NetResult<Void>> todo(@Query("todo") String todo);
    }
    
    @Override
    public Observable<NetResult<List<${NAME}Data>>> query() {
        return null;
    }
}