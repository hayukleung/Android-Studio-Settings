#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}Presenter implements ${NAME}Contract.Presenter {

    @NonNull
    private ${NAME}Contract.View mView;
    @NonNull
    private CompositeSubscription mSubscription;
    @NonNull
    private ${NAME}Repository mRepository;

    ${NAME}Presenter(@NonNull ${NAME}Contract.View view) {
        mView = view;
        mSubscription = new CompositeSubscription();
        mRepository = ${NAME}Injection.provide${NAME}Repository();
    }

    @Override
    public void subscribe() {
    }

    @Override
    public void unsubscribe() {
    }
    
    @Override
    public void query() {
        mSubscription.add(mRepository.query().subscribe(new NetSubscriber<List<${NAME}Data>>(mView) {
            @Override
            protected void onSuccess(int code, @Nullable Popup popup, @Nullable List<${NAME}Data> data) {
                mView.ui(data);
            }

            @Override
            public void onError(Throwable e) {
            }
        }));
    }
}