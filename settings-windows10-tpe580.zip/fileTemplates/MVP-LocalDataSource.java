#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}LocalDataSource implements ${NAME}DataSource {

    private ${NAME}LocalDataSource() {
    }

    public static ${NAME}LocalDataSource newInstance() {
        return new ${NAME}LocalDataSource();
    }
    
    @Override
    public Observable<NetResult<List<${NAME}Data>>> query() {
        return Observable.create(new QueryOnSubscribe())
                .subscribeOn(SchedulerProvider.getInstance().io())
                .observeOn(SchedulerProvider.getInstance().ui());
    }

    private static class QueryOnSubscribe implements Observable.OnSubscribe<NetResult<List<${NAME}Data>>> {

        @Override
        public void call(Subscriber<? super NetResult<List<${NAME}Data>>> subscriber) {

            NetResult<List<${NAME}Data>> result = new NetResult<>();
            result.data = new ${NAME}DataMocker().mock();
            subscriber.onNext(result);
            subscriber.onCompleted();
        }
    }
}