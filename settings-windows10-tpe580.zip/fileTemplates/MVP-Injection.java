#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}Injection extends BaseInjection {

    public static ${NAME}Repository provide${NAME}Repository() {
        return ${NAME}Repository.newInstance(${NAME}LocalDataSource.newInstance(), ${NAME}RemoteDataSource.newInstance());
    }
}