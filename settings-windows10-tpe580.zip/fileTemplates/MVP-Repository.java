#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}Repository implements ${NAME}DataSource {

    private ${NAME}LocalDataSource mLocalDataSource;
    private ${NAME}RemoteDataSource mRemoteDataSource;

    private ${NAME}Repository(${NAME}LocalDataSource localDataSource, ${NAME}RemoteDataSource remoteDataSource) {
        mLocalDataSource = localDataSource;
        mRemoteDataSource = remoteDataSource;
    }

    public static ${NAME}Repository newInstance(${NAME}LocalDataSource localDataSource, ${NAME}RemoteDataSource remoteDataSource) {
        return new ${NAME}Repository(localDataSource, remoteDataSource);
    }
    
    @Override
    public Observable<NetResult<List<${NAME}Data>>> query() {
        return mLocalDataSource.query();
    }
}