#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
public class ${NAME}Fragment extends BaseFragment implements ${NAME}Contract.View {

    private ${NAME}Contract.Presenter mPresenter;
    
    public static ${NAME}Fragment newInstance() {
        return new ${NAME}Fragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPresenter(new ${NAME}Presenter(this));
    }
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void setPresenter(@NonNull ${NAME}Contract.Presenter presenter) {
        mPresenter = presenter;
    }
    
    @Override
    public void ui(List<${NAME}Data> data) {
        // TODO
    }
}